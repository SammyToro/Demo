package com.torodesigns.rrpress;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class TellTheNews extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tell_the_news);

        String[] items = {"Politics,Business,Entertainment,Sports,Science,Health,Tech"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.list_item,items);
        AutoCompleteTextView category = (AutoCompleteTextView) findViewById(R.id.news_category);
        category.setAdapter(adapter);
    }
}
